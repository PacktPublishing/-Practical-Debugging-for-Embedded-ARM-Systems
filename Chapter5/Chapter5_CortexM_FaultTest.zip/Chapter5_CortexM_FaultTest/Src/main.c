/*********************************************************************
*                    SEGGER Microcontroller GmbH                     *
*                        The Embedded Experts                        *
**********************************************************************
*                                                                    *
*            (c) 2014 - 2020 SEGGER Microcontroller GmbH             *
*                                                                    *
*           www.segger.com     Support: support@segger.com           *
*                                                                    *
**********************************************************************
*                                                                    *
* All rights reserved.                                               *
*                                                                    *
* Redistribution and use in source and binary forms, with or         *
* without modification, are permitted provided that the following    *
* conditions are met:                                                *
*                                                                    *
* - Redistributions of source code must retain the above copyright   *
*   notice, this list of conditions and the following disclaimer.    *
*                                                                    *
* - Neither the name of SEGGER Microcontroller GmbH                  *
*   nor the names of its contributors may be used to endorse or      *
*   promote products derived from this software without specific     *
*   prior written permission.                                        *
*                                                                    *
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND             *
* CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,        *
* INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF           *
* MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE           *
* DISCLAIMED.                                                        *
* IN NO EVENT SHALL SEGGER Microcontroller GmbH BE LIABLE FOR        *
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR           *
* CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT  *
* OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;    *
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF      *
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT          *
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE  *
* USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH   *
* DAMAGE.                                                            *
*                                                                    *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

Purpose : Cortex-M Fault Exception test application.

*/

#include <stdio.h>
#include <stdlib.h>
#include "stm32f4xx.h"


#define _USE_DISTINCT_FAULTS    // If defined, enable usage fault, bus fault, and mem manage fault


/*********************************************************************
*
*       Local functions, generate fault with nice call stack
*
**********************************************************************
*/
#ifdef _NICE_CALL_STACK
#include <string.h>

static const char _abLogo[128*32];
static const char _abIcon[32*32];

#define _NUM_IMAGES 2
static struct {
  const char* sName;
  int         Width;
  int         Height;
  const char* pData;
} _aImg[_NUM_IMAGES] = {
  {"Logo.bmp", 128, 32, _abLogo},
  {"Icon.bmp", 32,  32, _abIcon}
};

/*********************************************************************
*
*       _GetPixel()
*
*  Function description
*   Get one pixel within an image.
*/
static char _GetPixel(const char* pImg, int x, int y, int Width, int Height) {
  return *(pImg +  (y * Width) + x);
}

/*********************************************************************
*
*       _GetImage()
*
*  Function description
*   Find the given image and get its informaiton.
*
*  Return value
*    == NULL: Image not found. Width and height not valid.
*    != NULL: Pointer to the image data.
*/
static const char* _GetImage(const char* sName, int* pWidth, int* pHeight) {
  int i;

  for (i = 0; i < _NUM_IMAGES; i++) {
    if (strcmp(sName, _aImg[i].sName) == 0) {
      *pWidth   = _aImg[i].Width;
      *pHeight  = _aImg[i].Height;
      return  _aImg[i].pData;
    }
  }

  return NULL;
}

/*********************************************************************
*
*       _GetFrameBuf()
*
*  Function description
*   Get the frame buffer and its dimensions.
*/
static char* _GetFrameBuf(int* pWidth, int* pHeight) {
  
  *pWidth = 1920;
  *pHeight = 1080;

  return (char*)0x20000000;
}

/*********************************************************************
*
*       _RenderImage()
*
*  Function description
*   Render an image to be written to the display.
*/
static void _RenderImage(void) {
  const char* pImg;
  char* pFrameBuf;
  char  Pixel;
  unsigned Width;
  unsigned Height;
  unsigned x;
  unsigned y;

  pFrameBuf = _GetFrameBuf(&Width, &Height);
  pImg = _GetImage("logo.bmp", &Width, &Height);

  for (y = 0; y < Height; y++) {
    for (x = 0; x < Width; x++) {
      Pixel = _GetPixel(pImg, x, y, Width, Height);
      *pFrameBuf = Pixel;
    }
  }
}
#endif

/*********************************************************************
*
*       Local functions, Bus faults
*
**********************************************************************
*/

/*********************************************************************
*
*       _IllegalRead()
*
*  Function description
*   Trigger a bus fault or hard fault by reading from a reserved address.
*
*  Additional Information
*    Bus fault is immediately triggered on the read instruction.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.BFSR = 0x00000082
*        PRECISERR = 1        - Precise data access violation
*        BFARVALID = 1        - BFAR is valid
*      NVIC.BFAR = 0x00100000 - The address read from
*/
static int _IllegalRead(void) {
  int r;
  volatile unsigned int* p;

  p = (unsigned int*)0x00100000;  // 0x00100000-0x07FFFFFF is reserved on STM32F4
  r = *p;

  return r;
}

/*********************************************************************
*
*       _IllegalWrite()
*
*  Function description
*   Trigger a bus fault or hard fault by writing to a reserved address.
*
*  Additional Information
*    Bus fault is triggered some instructions after the write instruction.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.BFSR = 0x00000004
*        IMPREISERR = 1       - Imprecise data access violation
*        BFARVALID = 0        - BFAR not valid
*/
static int _IllegalWrite(void) {
  int r;
  volatile unsigned int* p;

  r = 0;

  p = (unsigned int*)0x00100000;  // 0x00100000-0x07FFFFFF is reserved on STM32F4
  *p = 0x00BADA55;

  return r;
}

/*********************************************************************
*
*       _IllegalFunc()
*
*  Function description
*   Trigger a bus fault or hard fault by executing at a reserved address.
*
*  Additional Information
*    Bus fault is triggered on execution at the invalid address.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.BFSR = 0x00000001
*        IBUSERR = 1          - Bus fault on instruction prefetch
*/
static int _IllegalFunc(void) {
  int r;
  int (*pF)(void);

  pF = (int(*)(void))0x00100000;  // 0x00100000-0x07FFFFFF is reserved on STM32F4
  
  r = pF();

  return r;
}

/*********************************************************************
*
*       Local functions, Usage Faults
*
**********************************************************************
*/

/*********************************************************************
*
*       _NoThumbFunc()
*
*  Function description
*   Trigger a usage fault or hard fault by executing an address without thumb bit set.
*
*  Additional Information
*    Usage fault is triggered on execution at the invalid address.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.UFSR = 0x0002
*        INVSTATE = 1         - Instruction execution with invalid state
*/
static int _NoThumbFunc(void) {
  int r;
  int (*pF)(void);

  pF = (int(*)(void))0x00000000;
  
  r = pF();

  return r;
}

/*********************************************************************
*
*       _UndefInst()
*
*  Function description
*   Trigger a usage fault or hard fault by executing an undefined instruction.
*
*  Additional Information
*    Usage fault is triggered on execution at the invalid address.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.UFSR = 0x0001
*        UNDEFINSTR = 1       - Undefined instruction executed
*/
static int _UndefInst(void) {
  static const unsigned short _UDF[4] = {0xDEAD, 0xDEAD, 0xDEAD, 0xDEAD};
  int r;
  int (*pF)(void);

  pF = (int(*)(void))(((char*)&_UDF) + 1);
  
  r = pF();

  return r;
}

/*********************************************************************
*
*       _UnalignedAccess()
*
*  Function description
*   Trigger a usage fault or hard fault by an unaligned word access.
*
*  Additional Information
*    Usage fault is triggered immediately on the read or write instruction.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.UFSR = 0x0100
*        UNALIGNED = 1        - Unaligned memory access
*/
static int _UnalignedAccess(void) {
  int r;
  volatile unsigned int* p;

  p = (unsigned int*)0x20000002;  // 0x00100000-0x07FFFFFF is reserved on STM32F4
  r = *p;

  return r;
}

/*********************************************************************
*
*       _DivideByZero()
*
*  Function description
*   Trigger a usage fault or hard fault by dividing by zero.
*
*  Additional Information
*    Usage fault is triggered immediately on the divide instruction.
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x40000000
*        FORCED = 1           - bus fault/memory management fault/usage fault escalated to hard fault
*      NVIC.UFSR = 0x0200
*        DIVBYZERO = 1        - Divide-by-zero fault
*/
static int _DivideByZero(void) {
  int r;
  volatile unsigned int a;
  volatile unsigned int b;

  a = 1;
  b = 0;
  r = a / b;

  return r;
}

/*********************************************************************
*
*       Local functions, Hard faults
*
**********************************************************************
*/

/*********************************************************************
*
*       _IllegalVector()
*
*  Function description
*   Trigger a hard fault by interrupt with illegal vector table.
*
*  Additional Information
*    Related NVIC registers on hard fault:
*      NVIC.HFSR = 0x00000002
*        VECTTBL = 1           - Vector table read fault
*/
static int _IllegalVector(void) {
  int r;

  SCB->VTOR = 0x001000000;            // Relocate vector table to illegal address  
  SCB->ICSR = SCB_ICSR_PENDSVSET_Msk; // Trigger PendSV exception to read invalid vector

  __ISB();
  __DSB();

  return r;
}

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/
/*********************************************************************
*
*       main()
*
*  Function description
*   Application entry point.
*/
int main(void) {
  int r;
  //
  // Enable fault on divide-by-zero and unaligned access
  //
  SCB->CCR   |= SCB_CCR_DIV_0_TRP_Msk
             |  SCB_CCR_UNALIGN_TRP_Msk;

#ifdef _USE_DISTINCT_FAULTS
  //
  // Enable usage fault, bus fault, and mem manage fault
  //
  SCB->SHCSR |= SCB_SHCSR_USGFAULTENA_Msk 
             |  SCB_SHCSR_BUSFAULTENA_Msk
             |  SCB_SHCSR_MEMFAULTENA_Msk; // enable Usage-/Bus-/MPU Fault
#endif

#ifdef _NICE_CALL_STACK // Generate a "useful" call stack to test stack unwinding
  _RenderImage();
#endif
  //
  // Un-comment one of the following function calls to test the corresponding fault
  //
  //r = _UndefInst();
  //r = _NoThumbFunc();
  //r = _IllegalFunc();
  //r = _UnalignedAccess();
  //r = _DivideByZero();
  //r = _IllegalWrite();
  //r = _IllegalRead();
  //r = _IllegalVector();

  do {
    r++;
  } while (1);
}

/*************************** End of file ****************************/
