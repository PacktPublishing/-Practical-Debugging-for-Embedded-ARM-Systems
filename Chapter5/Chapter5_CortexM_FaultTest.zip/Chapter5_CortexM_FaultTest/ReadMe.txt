CortexM_FaultTest

Prerequisites:
- Embedded Studio V5.10b or later
- Ozone V3.20e or later
- J-Link Plus V11 or higher
- Cortex-M Trace Reference Board

HowTo:
1. Open the .emProject file with Embedded Studio
2. Comment in one of the Faulttests in the main() function
2.1. To enable the Faulttest which produces a "nice callstack" define _NICE_CALL_STACK
3. Compile the application by pressing F7
4. Open the Ozone.jdebug file with Ozone
5. Start Debugging in Ozone with F5 and let the application run over the selected Faulttest