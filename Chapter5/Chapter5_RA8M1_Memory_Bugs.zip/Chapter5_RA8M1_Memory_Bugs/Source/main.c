#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
#define ARRAY_SIZE 5
/*********************************************************************
*
*       Global data
*
**********************************************************************
*/
//
// Define a struct with an int array and a string
//
struct OverflowExample {
  int  aData[ARRAY_SIZE];       // Integer array to overflow
  char message[64];             // Adjacent string
};

/*********************************************************************
*
*       Static data
*
**********************************************************************
*/
static unsigned int _NumAllocations;

/*********************************************************************
*
*       Static functions
*
**********************************************************************
*/
char* _AllocateMemory(unsigned int size) {
  return (char *)malloc(size);
}

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/
//
// Function to demonstrate buffer overflow
//
void RunBufferOverflow(void) {
  struct OverflowExample Example;
  //
  // Initialize the message
  //
  strcpy(Example.message, "Secret message!");
  printf("Before Overflow: %s\n", Example.message);
  //
  // Intentionally overflow the data array
  // This will write beyond the end of data and affect the message
  //
  for (int i = 0; i <= ARRAY_SIZE; i++) {
      Example.aData[i] = i;                  // Assign values including overflow
  }
  //
  // Print the values after overflow
  //
  printf("After Overflow: %s\n", Example.message);
}

//
// Function to demonstrate memory leaks
//
void RunMemoryLeak(void) {
  //
  // Recursively allocate memory without freeing
  //
  char *leak = (char *)malloc(1024); // Allocate 1 KB chuncks
  _NumAllocations++;
  for (int i = 0; i < 1024; i++) { // Fill the allocated memory with some data (optional)
      leak[i] = 'Q'; // Example data
  }
  printf("Allocated %d kB at address 0x%p\n", _NumAllocations, (void*)leak);
  RunMemoryLeak(); // Recursive call
}

//
// Function to demonstrate nullpointer exceptions
//
void RunNullPtrTest(void) {
  char* pData;

  pData = _AllocateMemory(0x10000000);
  printf("The first byte of the allocated memory region is %d\n", *pData);
} 

//
// main function
// Comment in example functions one by one for testing
//
int main(void) {
  RunBufferOverflow();
  //RunMemoryLeak();
  //RunNullPtrTest();
  return 0;
}
