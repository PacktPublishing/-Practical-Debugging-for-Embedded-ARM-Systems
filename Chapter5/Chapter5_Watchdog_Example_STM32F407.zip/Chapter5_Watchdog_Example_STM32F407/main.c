#include <stdio.h>
#include <stm32f4xx.h>
#include <stdlib.h>

static volatile int _Ticks = 0;

void Watchdog_Init(unsigned int ReloadValue) {
    IWDG->KR = 0x5555;        // Enable write access to the IWDG
    IWDG->PR = IWDG_PR_PR_2;  // Set prescaler
    IWDG->RLR = ReloadValue;  // Set reload value
    IWDG->KR = 0xCCCC;        // Start the watchdog
}

void Feed_Watchdog(void) {
    IWDG->KR = 0xAAAA;  // Write magic value for refresh
}

void SysTick_Handler(void) {
  _Ticks++;
}

static void _Delay(int NumTicks) {
  unsigned int EndTicks;
  
  //Feed_Watchdog(); // Comment in our out to feed/ignore watchdog
  EndTicks = _Ticks + NumTicks;
  while (_Ticks < EndTicks);
}



/*********************************************************************
*
*       main()
*
*  Function description
*   Application entry point.
*/
int main(void) {
  int i;

  i = 0;
  Watchdog_Init(1000);  // Comment in our out to enable/disable watchdog
  SystemCoreClockUpdate();
  //
  // Enable SysTick timer interrupt.
  // Set it to millisecond tick.
  //
  SysTick->LOAD = (SystemCoreClock / 1000) - 1;
  SysTick->VAL = 0;
  SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
  // 
  // Display tick count every second
  //
  while (1) {
    printf("Tick value = %d\n", _Ticks);
    _Delay(1000); // Delay for one second
  }
}

/*************************** End of file ****************************/
