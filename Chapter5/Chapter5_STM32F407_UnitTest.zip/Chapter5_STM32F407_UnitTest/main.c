#include "stm32f4xx.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>

//
// Function prototypes
//
void TIM2_Init(void);
bool TIM2_TestInitialization(void);

//
// Initializes timer TIM2
//
void TIM2_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; // Enable the clock for TIM2
    TIM2->PSC = 16000 - 1; // Prescaler value for 1 ms tick (assuming 16 MHz clock)
    TIM2->ARR = 1000 - 1;  // Count for 1000 ms (1 second)
    TIM2->DIER |= TIM_DIER_UIE; // Enable the update interrupt
    TIM2->CR1 |= TIM_CR1_CEN; // Enable the counter
    //
    // Log initialization success
    //
    printf("LOG: TIM2 initialized successfully.\n");
}

//
// Generic TIM2 interrupt handler
//
void TIM2_IRQHandler(void) {
    if (TIM2->SR & TIM_SR_UIF) { // Check if the update interrupt flag is set
        TIM2->SR &= ~TIM_SR_UIF; // Clear the interrupt flag
    }
}

bool TIM2_TestInitialization(void) {
    TIM2_Init();
    if (TIM2->PSC != 16000 - 1) { // Check if the prescaler is set correctly
        printf("ERROR: Prescaler not set correctly.\n");
        return false;
    }
    if (TIM2->ARR != 1000 - 1) { // Check if the auto-reload register is set correctly
        printf("ERROR: ARR not set correctly.\n");
        return false;
    }
    if (!(TIM2->CR1 & TIM_CR1_CEN)) { // Check if the timer is enabled
        printf("ERROR: Timer not enabled.\n");
        return false;
    }
    if (!(TIM2->DIER & TIM_DIER_UIE)) { // Check if update interrupt is enabled
        printf("ERROR: Update interrupt not enabled.\n");
        return false;
    }
    printf("SUCCESS: TIM2 initialized and tested successfully.\n");
    return true; // Passed all tests
}

//
// Main Function for Testing
//
int main(void) {
    printf("START\nStarting TIM2 Initialization Test...\n");
    if (TIM2_TestInitialization()) { // Timer initialized successfully
        printf("PASSED: Timer Test Passed.\n");
        printf("END\n");
        return 0;
    } else {
        printf("FAILED: Timer Test Failed.\n"); // Initialization failed
        printf("END\n");
        return -1;
    }
}
