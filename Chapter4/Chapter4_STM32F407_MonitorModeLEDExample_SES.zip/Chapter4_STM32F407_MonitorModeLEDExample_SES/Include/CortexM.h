/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : CortexM.h
Purpose : Cortex M peripheral defines
*/

#ifndef CORTEXM_H            // Avoid multiple inclusion.
#define CORTEXM_H

#if defined(__cplusplus)
  extern "C" {                // Make sure we have C-declarations in C++ programs.
#endif

/*********************************************************************
*
*       Global defines
*
**********************************************************************
*/

#define SYSTICK           ((SYSTICK_REGS*)0xE000E010)
#define SCS               ((SCS_REGS*)0xE000ED00)

/*********************************************************************
*
*       Global types
*
**********************************************************************
*/

typedef struct {
  volatile unsigned int CSR;
  volatile unsigned int RVR;
  volatile unsigned int CVR;
  volatile unsigned int CALIB;
} SYSTICK_REGS;

typedef struct {
  volatile unsigned int CPUID;       // CPUID Base Register
  volatile unsigned int ICSR;        // Interrupt Control and State Register
  volatile unsigned int VTOR;        // Vector Table Offset Register
  volatile unsigned int AIRCR;       // Application Interrupt and Reset Control Register
  volatile unsigned int SCR;         // System Control Register
  volatile unsigned int CCR;         // Configuration and Control Register
  volatile unsigned int SHPR1;       // System Handler Priority Register 1
  volatile unsigned int SHPR2;       // System Handler Priority Register 2
  volatile unsigned int SHPR3;       // System Handler Priority Register 3
  volatile unsigned int SHCSR;       // System Handler Control and State Register
  volatile unsigned int CFSR;        // Configurable Fault Status Register
  volatile unsigned int HFSR;        // HardFault Status Register
  volatile unsigned int DFSR;        // Debug Fault Status Register
  volatile unsigned int MMFAR;       // MemManage Fault Address Register
  volatile unsigned int BFAR;        // BusFault Address Register
  volatile unsigned int AFSR;        // Auxiliary Fault Status Register
  volatile unsigned int aDummy0[4];  // 0x40-0x4C Reserved
  volatile unsigned int aDummy1[4];  // 0x50-0x5C Reserved
  volatile unsigned int aDummy2[4];  // 0x60-0x6C Reserved
  volatile unsigned int aDummy3[4];  // 0x70-0x7C Reserved
  volatile unsigned int aDummy4[2];  // 0x80-0x87 - - - Reserved.
  volatile unsigned int CPACR;       // Coprocessor Access Control Register
} SCS_REGS;

/*********************************************************************
*
*       External variables
*
**********************************************************************
*/
extern unsigned int _vectors[];

#if defined(__cplusplus)
}                             // Make sure we have C-declarations in C++ programs.
#endif

#endif                        // Avoid multiple inclusion.

/*************************** End of file ****************************/
