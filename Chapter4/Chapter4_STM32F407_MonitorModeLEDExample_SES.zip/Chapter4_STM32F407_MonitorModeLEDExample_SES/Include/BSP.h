/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : BSP.h
Purpose : Board Support Package
*/

#ifndef BSP_H                           /* avoid multiple inclusion */
#define BSP_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************
*
*       API functions
*
**********************************************************************
*/
void     BSP_Init       (void);
void     BSP_SetLED     (int Index);
void     BSP_ClrLED     (int Index);
void     BSP_ToggleLED  (int Index);

#ifdef __cplusplus
}
#endif

/********************************************************************/

#endif                                  /* avoid multiple inclusion */

/****** End Of File *************************************************/
