/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : main.h
Purpose : Header file of main module
*/

#ifndef MAIN_H            // Avoid multiple inclusion.
#define MAIN_H

#if defined(__cplusplus)
  extern "C" {                // Make sure we have C-declarations in C++ programs.
#endif

/*********************************************************************
*
*       API functions
*
**********************************************************************
*/
void MAIN_MonitorOnPoll   (void);
void MAIN_MonitorOnEnter  (void);
void MAIN_MonitorOnExit   (void);

#if defined(__cplusplus)
}                             // Make sure we have C-declarations in C++ programs.
#endif

#endif                        // Avoid multiple inclusion.

/*************************** End of file ****************************/
