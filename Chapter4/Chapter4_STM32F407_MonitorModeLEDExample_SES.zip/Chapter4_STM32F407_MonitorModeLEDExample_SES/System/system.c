/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : system.c
Purpose : System specific setup code
*/

#define SYSTEM_C

#include "CortexM.h"

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/

/*********************************************************************
*
*       SystemInit()
*
*  Function description
*    Initializes the system specific peripherals
*/
void SystemInit (void);
void SystemInit (void) {
  //
  // Set Vector Table Offset ASAP after reset for monitor mode debugging
  //
  SCS->VTOR = (unsigned int)_vectors;
  //
  // Enable FPU with full access
  //
  SCS->CPACR |= (0xF << 20);
  asm volatile("DSB");
  asm volatile("ISB");
}

/*************************** End of file ****************************/

