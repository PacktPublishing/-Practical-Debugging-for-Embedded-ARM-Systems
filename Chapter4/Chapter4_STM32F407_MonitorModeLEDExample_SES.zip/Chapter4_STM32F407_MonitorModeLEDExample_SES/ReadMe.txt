This project was built for SEGGER Embedded Studio V8.24.

Purpose:
========
This example project demonstrates how monitor mode debugging works.
The main application blinks the green LED0 while running. When application is halted by
the debugger (e.g. breakpoint) the monitor code will execute and the green LED1 will blink.

Supported hardware:
===================
The example project for the ST STM32F407 is prepared
to run on a Segger Cortex-M Trace Reference Board, but
may be used on other target hardware as well.

Tested on Cortex-M Trace Reference Board V1.4.

Using different target hardware may require modifications.
