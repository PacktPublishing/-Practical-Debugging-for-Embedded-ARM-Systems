/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : Main.c
Purpose : Main application to demonstrate monitor mode debugging with J-Link,
          while keeping certain interrupts firing when main application is halted.
*/

#define MAIN_C

#include "BSP.h"
#include "main.h"
#include "CortexM.h"
#include <stdio.h>

/*********************************************************************
*
*       Defines, configurable
*
**********************************************************************
*/
#define _LED_MAIN_IDX    (0)
#define _LED_MONITOR_IDX (1)

/*********************************************************************
*
*       Static data
*
**********************************************************************
*/
volatile static int _SysTckCnt = 0;   // Incremented by user application
static int _JLINK_MONITOR_Ready = 0;

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/

/*********************************************************************
*
*       MAIN_MonitorOnEnter
*/
void MAIN_MonitorOnEnter(void) {
  if (_JLINK_MONITOR_Ready != 1) {
    return;
  }
  BSP_ClrLED(_LED_MAIN_IDX);
}

/*********************************************************************
*
*       MAIN_MonitorOnExit
*/
void MAIN_MonitorOnExit(void) {
  if (_JLINK_MONITOR_Ready != 1) {
    return;
  }
  BSP_ClrLED(_LED_MONITOR_IDX);
}

/*********************************************************************
*
*       MAIN_MonitorOnPoll
*
*  Function description
*    Called periodically from monitor while CPU is in monitor mode during debugging.
*    Call of this function has been added to JLINK_MONITOR_OnPoll() in JLINK_MONITOR.c
*/
void MAIN_MonitorOnPoll(void) {
  unsigned v;

  if (_JLINK_MONITOR_Ready != 1) {
    return;
  }
  v = _SysTckCnt & 0x1FF;
  if (v < 0x100) {
    BSP_SetLED(_LED_MONITOR_IDX);    // Do not call original BSP_ToggleLED() as it is also called from application code, so if also called from monitor, source level stepping into this function would no longer word
  } else {
    BSP_ClrLED(_LED_MONITOR_IDX);
  }
}

/*********************************************************************
*
*       SysTick_Handler()
*
*  Function description
*    Interrupt service routine called by SysTick interrupt.
*
*  Notes
*    (1) As it is configured in main() with a higher priority than the debug monitor, this routine cannot be debugged in monitor mode
*/
void SysTick_Handler(void);
void SysTick_Handler(void) {
  _SysTckCnt++;
}

/*********************************************************************
*
*       Local functions
*
**********************************************************************
*/

void _Delay(unsigned int);
void _Delay(unsigned int iTicks) {
  unsigned int TckEnd;

  TckEnd = _SysTckCnt + iTicks;
  while (_SysTckCnt < TckEnd) {
    ;   // Wait loop
  }
}

/*********************************************************************
*
*       main()
*/
int main(void) {
  unsigned int v;

  BSP_Init();
  //
  // Main application blinks LED0 during normal running mode.
  // When application is halted due to debugger events monitor mode is executing
  // and LED1 is blinking while LED0 is off.
  //
  // Configure SysTick and debug monitor interrupt priorities
  // Low value means high priority
  // A maximum of 8 priority bits and a minimum of 3 bits is implemented per interrupt.
  // How many bits are implemented depends on the actual CPU being used
  // If less than 8 bits are supported, the lower bits of the priority byte are RAZ.
  // In order to make sure that priority of monitor and SysTick always differ, please make sure that the difference is visible in the highest 3 bits
  //
  v = SCS->SHPR3;
  v |= (0xFF << 0);       // Set priority of debug monitor to lowest priority so all interrupts keep firing while application is halted
  v &= ~(0xFFuL << 24);   // Highest prio for SysTick
  // v |= (0x80uL << 24);    // Set higher priority for SysTick than for debug monitor
  SCS->SHPR3 = v;
  //
  // Configure SysTick timer
  //
  SYSTICK->RVR = 0x7FFF;    // Set reload value
  SYSTICK->CVR = 0x00;      // Set counter to zero
  SYSTICK->CSR = 0x07;      // Enable SysTick timer
  //
  // Setup code is done at this point.
  //
  printf("Application is now ready!\n");
  _JLINK_MONITOR_Ready = 1;
  //
  // Main application loop
  //
  while (1) {
    BSP_ToggleLED(_LED_MAIN_IDX);
    _Delay(100);
  }
}
