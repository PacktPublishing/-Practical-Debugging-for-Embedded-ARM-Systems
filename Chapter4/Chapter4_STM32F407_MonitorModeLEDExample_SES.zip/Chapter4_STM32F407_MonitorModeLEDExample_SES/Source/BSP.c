/*********************************************************************
*                   (c) SEGGER Microcontroller GmbH                  *
*                        The Embedded Experts                        *
*                           www.segger.com                           *
**********************************************************************

-------------------------- END-OF-HEADER -----------------------------

File    : BSP.c
Purpose : BSP for Segger Cortex-M Trace Reference Board
*/

#include "BSP.h"

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
#define NUM_LEDS 3u

#define GPIOA ((GPIO_REGS*)0x40020000)
#define RCC   ((RCC_REGS*) 0x40023800)

/*********************************************************************
*
*       Typedefs
*
**********************************************************************
*/

typedef struct _RCC {
  volatile unsigned int CR;
  volatile unsigned int PLLLCFGR;
  volatile unsigned int CFGR;
  volatile unsigned int CIR;
  volatile unsigned int AHB1RSTR;
  volatile unsigned int AHB2RSTR;
  volatile unsigned int AHB3RSTR;
  volatile unsigned int _aDummy0[1];
  volatile unsigned int APB1RSTR;
  volatile unsigned int APB2RSTR;
  volatile unsigned int _aDummy1[2];
  volatile unsigned int AHB1ENR;
  volatile unsigned int AHB2ENR;
  volatile unsigned int AHB3ENR;
  volatile unsigned int _aDummy2[1];
  volatile unsigned int APB1ENR;
  volatile unsigned int APB2ENR;
  volatile unsigned int _aDummy3[2];
} RCC_REGS;

typedef struct _GPIO_REGS {
  volatile unsigned int MODER;
  volatile unsigned int OTYPER;
  volatile unsigned int OSPEEDR;
  volatile unsigned int PUPDR;
  volatile unsigned int IDR;
  volatile unsigned int ODR;
  volatile unsigned int BSRR;
  volatile unsigned int LCKR;
  volatile unsigned int AFRL;
  volatile unsigned int AFRH;
} GPIO_REGS;

typedef struct _LED_INFO {
  int PortPin;
  GPIO_REGS *Port;
} LED_INFO;

/*********************************************************************
*
*       Static data
*
**********************************************************************
*/
static LED_INFO _aLEDInfo[] = {
  {10, GPIOA },  // LED0 GREEN
  { 9, GPIOA },  // LED1 GREEN
  { 8, GPIOA },  // LED2 GREEN
};

/*********************************************************************
*
*       Global functions
*
**********************************************************************
*/

/*********************************************************************
*
*       BSP_Init()
*/
void BSP_Init(void) {
  unsigned int reg, i;

  //
  // Enable GPIO clock for Port A
  //
  (RCC->AHB1ENR) |= (1 << 0);
  for (i = 0; i < NUM_LEDS; i++) {
    //
    // Configure as GPIO Output in Push-Pull mode
    //
    _aLEDInfo[i].Port->MODER &= ~(3 << (_aLEDInfo[i].PortPin * 2));
    _aLEDInfo[i].Port->MODER |= (1 << (_aLEDInfo[i].PortPin * 2));
    _aLEDInfo[i].Port->OTYPER &= ~(1 << _aLEDInfo[i].PortPin);
    //
    // Clear LED by setting Pin to HIGH (inverted polarity)
    //
    _aLEDInfo[i].Port->BSRR |= (1 << (_aLEDInfo[i].PortPin));
  }
}

/*********************************************************************
*
*       BSP_SetLED()
*/
void BSP_SetLED(int Index) {
  if (Index < (int)NUM_LEDS) {
   (_aLEDInfo[Index].Port->BSRR) = (1u << (_aLEDInfo[Index].PortPin + 16));
  }
}

/*********************************************************************
*
*       BSP_ClrLED()
*/
void BSP_ClrLED(int Index) {
  if (Index < (int)NUM_LEDS) {
   (_aLEDInfo[Index].Port->BSRR) = (1u << (_aLEDInfo[Index].PortPin));
  }
}

/*********************************************************************
*
*       BSP_ToggleLED()
*/
void BSP_ToggleLED(int Index) {
  unsigned int mask;

  if (Index < (int)NUM_LEDS) {
    mask = (1u << _aLEDInfo[Index].PortPin);
    //
    // Toggle pin output state
    //
    if (((_aLEDInfo[Index].Port->ODR) & mask) == mask)
    {
      (_aLEDInfo[Index].Port->BSRR) = (1u << (_aLEDInfo[Index].PortPin + 16));
    }
    else
    {
      (_aLEDInfo[Index].Port->BSRR) = (1u << _aLEDInfo[Index].PortPin);
    }
  }
}

/****** End Of File *************************************************/
